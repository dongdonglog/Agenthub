---
name: victorialogs-query
description: 查现场服务日志时使用。触发场景：用户说"查日志"、"看某服务这几天有没有报错"、"为什么搜不到日志"、"VictoriaLogs 查询"、"日志平台打不开"、"按关键词过滤日志"。覆盖 dashboard → sqlbackend → VictoriaLogs 这条链路、接口参数和常见查询写法。
license: Proprietary. See LICENSE in the repository root.
metadata:
  owner: donglai.ye
  version: 1.1.0
  updated: "2026-11-11"
  source: platform/devops/victorialogs-*
---

# VictoriaLogs 查询

## 链路

```text
浏览器 dashboard (Vue3, nginx:80)  →  sqlbackend (Go/Gin, :8080)  →  VictoriaLogs (:9428)
```

两个仓库的**部署分支都是 `pro`**，不是 `main`。前端请求路径是 `/api/v1/logs`（`VITE_API_BASE` 默认 `/api`）。

## 接口

后端只有两个路由：

| 方法 | 路径 | 用途 |
|---|---|---|
| GET | `/api/v1/health` | 健康检查，返回 `service/status/time` |
| GET | `/api/v1/logs` | 查询，转发到 VictoriaLogs 的 `/select/logsql/query` |

`/api/v1/logs` 的参数：

| 参数 | 必填 | 说明 |
|---|---|---|
| `query` | 是 | LogsQL 查询串，直接透传给 VictoriaLogs |
| `start` / `end` | 否 | RFC3339，如 `2026-11-11T01:00:00Z`；不传默认最近 1 小时 |
| `limit` | 否 | 默认 1000，超过 100000 会被截到 100000 |
| `keyword` | 否 | 拿到结果后做过滤/高亮，**不是查询条件** |
| `filter` | 否 | 是否启用 `config.yaml` 里的 `default_keywords` 过滤 |
| `context_before` / `context_after` | 否 | 上下文行数，最大 50 |

返回统一包装 `{code, message, data}`：

| code | 含义 |
|---|---|
| 0 | 成功 |
| 40001 | 参数错误（时间不是 RFC3339 也走这个） |
| 50201 | VictoriaLogs 请求失败或返回非 200 |
| 50001 | 解析上游响应失败 |

## 直查（绕过页面）

```bash
# 后端活着吗
curl -s "http://<sqlbackend>:8080/api/v1/health"

# 走一遍后端，最接近页面实际行为
curl -s "http://<sqlbackend>:8080/api/v1/logs?query=error&limit=20"

# 直接问 VictoriaLogs，确认存储里有没有数据
curl -s "http://<victorialogs-host>:9428/select/logsql/query" \
  -d 'query=error' -d 'limit=3'
```

## 查不到日志：先分三段

```bash
# 1. 采集端（vector 是 DaemonSet，在 logging 命名空间）
kubectl -n logging get pod -l app=vector
kubectl -n logging logs -l app=vector --tail=50

# 2. 存储里有数据吗（上面第三条 curl）
# 3. 后端活着吗（上面第一条 curl）
```

三段都对还是空，问题在查询本身：字段名写错、时间范围没覆盖、或者 `filter` 把结果滤掉了。

**先看一条真实记录再写查询**，字段名别猜：

```bash
curl -s "http://<host>:9428/select/logsql/query" -d 'query=*' -d 'limit=1'
```

## 时间范围

- 接口只认 RFC3339，`2026-11-11T01:00:00Z`。写成 `2026-11-11 09:00` 会直接 40001，不是"查不到"。
- 不传 `start`/`end` 就是最近 1 小时（`now-1h` 到 `now`，服务端按 UTC 算）。
- 页面上的相对时间会先换算成 UTC 的 ISO 串再发，所以页面和 curl 的结果应当一致；不一致说明两边时间参数不同。

## 配置

| 变量 | 作用 |
|---|---|
| `VICTORIALOGS_CONFIG` | 指定配置文件路径 |
| `VICTORIALOGS_BASE_URL` | 覆盖 VictoriaLogs 地址 |

默认 `config.yaml`：`port: 8080`、`base_url: http://victorialogs:9428`、`timeout: 30s`、`max_retries: 1`。

加过滤关键词：改 `config.yaml` 的 `filters.default_keywords`，并把 `enable_filtering` 打开，重启后端。前端不用动。

## 部署

两个仓库各有自己的 K8s 清单（`victorialogs-frontend.yaml` / `victorialogs-backend.yaml`）。前端 nginx 反代到后端，改端口或名字时两处都要动。

**已知的不一致**：CI 推的镜像名（`victoralogs-backend`，少个 i）、Deployment 拉的名字、分支 tag 三者对不上。改之前先看清单里实际写的是什么。

## 别做

- 不要 `query=*` 查大范围：会把 VictoriaLogs 打满，加 `_time` 或过滤条件。
- 不要只改 `main` 就以为上线了：部署走 `pro`。
- 不要前后端只升一个：接口字段会不匹配。
- 不要把 `keyword` 当查询条件：它只过滤已取回的结果。
- 不要用 `latest` 当部署 tag：`rollout restart` 才换镜像，容易误判"更新没生效"。

## 深入

- [references/query-cookbook.md](references/query-cookbook.md)：常用查询、字段名、时间写法
- [references/evidence.md](references/evidence.md)：每条结论的出处

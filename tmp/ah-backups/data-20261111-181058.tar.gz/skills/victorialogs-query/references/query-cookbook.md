# 查询速查

VictoriaLogs 用 LogsQL，语法参考官方文档 <https://docs.victoriametrics.com/victorialogs/logsql/>。下面这些在官方 querying 文档里有对应示例。

## 时间

```text
query=*  _time:1h          最近 1 小时
query=*  _time:1d          最近 24 小时
```

`_time:` 是 LogsQL 的相对时间语法。走接口时也可以用 `start` / `end`：

```bash
curl -s "http://<host>:9428/select/logsql/query" \
  -d 'query=error' \
  -d 'start=2026-11-10T00:00:00Z' \
  -d 'end=2026-11-11T00:00:00Z' \
  -d 'limit=100'
```

**必须带时区**（`Z` 或 `+08:00`）。不带时区的字符串会被判为格式错误。

## 字段名从哪来

日志由 `vector` 采集，配置在 `online-install/vector-vmlogs/vector.yaml`，写进去的字段是：

```text
kubernetes.pod_namespace
kubernetes.pod_name
kubernetes.container_name
message（同时被复制到 _msg）
```

**但存储里的实际字段名要先确认**，不同版本的归一化规则可能把点换成下划线。先取一条看：

```bash
curl -s "http://<host>:9428/select/logsql/query" -d 'query=*' -d 'limit=1'
```

或者列字段：

```bash
curl -s "http://<host>:9428/select/logsql/field_names" -d 'query=*' -d 'limit=50'
```

## 常用过滤

```text
# 裸词默认匹配 _msg 字段
error
"connection refused"

# 指定字段
kubernetes.container_name:"my-service"

# 组合
kubernetes.container_name:"my-service" AND (error OR timeout)
kubernetes.container_name:"my-service" AND NOT "health check"
```

## 聚合

```text
# 按级别计数
query=* _time:1d | stats count() as c by (level)

# 每个容器的错误数
query=error _time:1d | stats count() as c by (kubernetes.container_name) | sort by (c) desc

# 每分钟条数，看有没有断流
query=* _time:1h | stats count() as c by (_time:1m)
```

聚合语法属于 LogsQL 的 pipe 部分，第一次用先在页面上试，别在脚本里写复杂聚合。

## 取最新几条

```text
query=kubernetes.container_name:"my-service" | sort by (_time) desc | limit 20
```

## 排查套路

| 想确认 | 查法 |
|---|---|
| 这个服务有没有在打日志 | `kubernetes.container_name:"<svc>" _time:10m \| limit 5` |
| 有没有报错 | `kubernetes.container_name:"<svc>" AND (error OR panic OR fatal) _time:1h` |
| 什么时候开始出问题 | 按分钟计数，看曲线哪一分钟断开或突增 |
| 是不是只有某个实例 | `stats count() as c by (kubernetes.pod_name)` |
| 重启了几次 | 搜启动日志特征串，按 pod 分组计数 |

## 常见错误

| 报错/现象 | 原因 |
|---|---|
| `40001 invalid query range` | `start`/`end` 不是 RFC3339，或带了不带时区的时间 |
| `40001 invalid query parameters` | `query` 为空 |
| `50201 victoriaLogs request failed` | sqlbackend 连不上 9428，或 VictoriaLogs 挂了 |
| `50001 failed to parse` | 上游返回格式变了，看后端日志里的 `status_code` 和 `body` |
| 查出来为空但采集正常 | 字段名不对，或时间范围没覆盖 |
| 结果被莫名其妙过滤 | `filter` 开着且 `default_keywords` 命中了 |

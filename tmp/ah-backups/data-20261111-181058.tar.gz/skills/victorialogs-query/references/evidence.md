# 依据

路径相对 `platform/devops/victorialogs-sqlbackend` 与 `platform/devops/victorialogs-dashboard`。

## 已验证

| 结论 | 依据 | 类型 |
|---|---|---|
| 只有两个路由：`GET /api/v1/health`、`GET /api/v1/logs` | `victorialogs-sqlbackend/main.go:58-61` | 代码 |
| 前端请求 `/api/v1/logs`，`API_BASE` 默认 `/api` | `victorialogs-dashboard/src/App.vue:371,593` | 代码 |
| 上游路径是 `/select/logsql/query` | `victorialogs-sqlbackend/handlers.go:19` | 代码 |
| 参数名 `query/start/end/limit/filter/keyword/context_before/context_after` | `handlers.go:359-368`（struct tag） | 代码 |
| `query` 必填，其余可选 | `handlers.go:360` 的 `binding:"required"` | 代码 |
| 默认 limit 1000，上限 100000；上下文最多 50 行 | `handlers.go:21-23`、`396-406` | 代码 |
| 不传时间默认最近 1 小时（`now-1h` 到 `now`） | `handlers.go:382-390` | 代码 |
| 时间只接受 RFC3339，否则报错 | `handlers.go:425-436`（`parseTime`） | 代码 |
| 返回包装 `{code, message, data}`，成功 code=0 | `handlers.go:458-476` | 代码 |
| 错误码 40001 / 50201 / 50001 | `handlers.go:25-28` | 代码 |
| 默认配置 `port: 8080`、`base_url: http://victorialogs:9428`、`timeout: 30s`、`max_retries: 1` | `victorialogs-sqlbackend/config.yaml` | 文件 |
| 采集字段名 `kubernetes.container_name` 等，`_msg` 是复制出来的消息字段 | `online-install/vector-vmlogs/vector.yaml:32-38` | 代码 |
| 部署分支是 `pro` | 两个仓库 `git branch -r` 都有 `origin/pro`，`main` 停在 2026-01-15 | 代码 |

## 外部资料

| 结论 | 来源 |
|---|---|
| `/select/logsql/query` 的 `query` 参数、`-d` 传参方式、`limit` | VictoriaLogs 官方文档 <https://docs.victoriametrics.com/victorialogs/querying/>（页面里就有 `curl ... -d 'query=error' -d 'limit=10'` 的例子） |
| `_time:1h` 相对时间语法 | 同上，示例 `query=_time:1h error` |
| 裸词默认匹配 `_msg` 字段 | 同上，原文 "log entries with the error word in the `_msg` field" |
| `stats` / `sort` 等 pipe 语法 | <https://docs.victoriametrics.com/victorialogs/logsql/> |

## 未验证

| 结论 | 状态 | 怎么确认 |
|---|---|---|
| 存储里字段名到底用点还是下划线 | **不确定**。vector 写的是 `kubernetes.container_name`，官方文档的响应示例里出现的是 `kubernetes_container_name` | 现场 `curl ... -d 'query=*' -d 'limit=1'` 看实际字段，或 `/select/logsql/field_names` |
| 页面和 curl 的时间范围一定一致 | 逻辑上应该一致（都传 UTC ISO），未逐页比对 | 同一时间窗口两边各查一次比总数 |
| `id` 前后端接口字段是否一一对应 | 只读了请求侧，没读完整响应映射 | 抓一次页面请求的响应体 |

## 引用来源

- 交接文档：`04-手册/07-victorialogs.md`
- 官方文档：<https://docs.victoriametrics.com/victorialogs/querying/>

# 组件模板清单

引用方式：

```yaml
include:
  - component: $CI_SERVER_FQDN/platform/devops/cicd/moying-cicd/<模板>@<版本>
    inputs:
      <key>: <value>
```

注意路径里有 `cicd/`。老文档写的 `platform/devops/moying-cicd` 少一段，照抄会报 component not found。

## 全家桶（新项目用这些）

| 模板 | 干什么 | 必填 input | 产出 |
|---|---|---|---|
| `backend-go-service` | Go 后端：单测→集成→Sonar→构建→部署→提升 | `image_name`、`sonar_project_key`、`deploy_service_name` | 镜像 |
| `backend-jvm-service` | JVM 后端（Java/Kotlin/Gradle）同链路 | 同上 + `package_cmd` | 镜像 |
| `frontend-node-app` | Node 前端：install→typecheck→build→部署 | `pnpm_store`、`sonar_project_key` | 静态产物 |
| `static-site-app` | 文档站、官网 | `builder_image` | 站点包 |
| `electron-linux-app` | Electron Linux 桌面应用 | stage 名、`pnpm_*` | 安装包 |
| `android-apk-app` | Android APK | `apk_basename` | apk |
| `ros2-full-build` | ROS2 全量构建出 `.deb` | `build_image`、`deb_package_name` | deb |

## 单步（已有流水线的项目用）

| 模板 | 干什么 | 关键 input |
|---|---|---|
| `go-unit-test` / `go-integration-test` / `go-test` | 拆开的 Go 测试 | `unit_test_cmd` / `test_flags` |
| `go-code-scan` / `sonar-scan` | Sonar 扫描 | `sonar_project_key`、`sonar_host_url` |
| `node-install` / `node-typecheck` / `node-build` | 拆开的前端步骤 | `tsc_args`、`build_cmd` |
| `docker-build-push` | 通用构建推送 | `image_name`、`dockerfile` |
| `docker-promote` | rc → 正式提升 | `image_name` |
| `docker-mirror` | 批量同步镜像（matrix） | `source_prefix`、`target_prefix`、`images` |
| `dcli-deploy` | dcli 部署到测试环境 | `service_name`、`env_name`、`test`、`replicas` |
| `upload-artifact` | 把 deb 传到制品平台 | `deb_globs`、`download_token_variable` |
| `promote-and-upload-release` | 提升 + 上传发布制品 | `rc_deb_paths`、`promote_image` |
| `artifact-notify-dingtalk` | 钉钉通知制品链接 | `artifact_links` |
| `ai-code-review` | MR AI 审查 | `ocr_language`、`fail_on_severity`、`allow_failure` |

## 运行时要求

所有模板默认要求：

- runner 标签同时有 `shell` 和 `ci-02`；
- runner 宿主机装了 Docker；
- 宿主机已登录镜像仓库；
- 项目的 `stages` 包含模板用到的 stage 名。

## 灰度入口

`entry/with-ai-review.yml` 是包装文件，业务项目不用改自己的 `.gitlab-ci.yml`，只改一个设置：

```text
Settings → CI/CD → General pipelines → CI/CD configuration file
填：entry/with-ai-review.yml@platform/devops/cicd/moying-cicd
```

它做三件事：加载项目自己的配置、追加 `ai-code-review`（灰度期 `allow_failure: true`）、追加 `agents-check`（强制门禁）。回滚就是把这个设置清空。

# 流水线排障

## 流水线没起来

| 检查 | 命令/位置 | 判断 |
|---|---|---|
| tag 格式 | 对照 `^\d+\.\d+\.\d+-(alpha\|test\|rc)\.\d+$` | 不匹配就不触发，beta 也不触发 |
| tag 推上去了没 | `git ls-remote --tags origin \| grep 1.2.0` | 本地有、远端没有等于没推 |
| 影响范围 | Pipelines 列表 | 只有 tag 才构建，MR 只跑检查 |

## 流水线一直 pending

runner 匹配不上。项目 → Settings → CI/CD → Runners，看有没有同时带 `shell` 和 `ci-02` 标签的 runner。

pending 不报错，很容易误判成"卡住了"。

## 报 component not found

```
Component not found: platform/devops/moying-cicd/backend-go-service@1.2.0
```

三种原因：

1. 路径少了 `cicd/`（最常见）；
2. 版本 tag 不存在：`git ls-remote --tags <repo> | grep 1.2.0`；
3. 项目没有读组件的权限。

## 报 stage does not exist

项目 `.gitlab-ci.yml` 的 `stages` 少了模板用到的 stage。全家桶要这六个，顺序不要改：

```yaml
stages: [unit-test, integration-test, code-scan, build, deploy-test, promote]
```

## 构建成功但镜像没有

```bash
grep -i "unauthorized\|denied" <job 日志>
```

- `unauthorized`：runner 的 `docker login` 过期，重新登录；
- `denied`：账号没有 push 权限，找镜像仓库管理员。

也可能推到了别的地址：看 job 日志里的 `docker push` 那行完整镜像名。

## 部署测试失败：service not found

`deploy-test` 的 `-s` 取的是 `dcli.yml` 里的服务名，不是镜像名、不是仓库名。去项目根找 `dcli.yml` 对一下。

## promote 报 requires an alpha/test/rc tag

`docker-promote` 只能在预发布 tag 的流水线上点。裸版本 tag 上不会出现这个按钮，出现了说明规则被改过。

## 改了模板但业务项目没变化

业务项目锁的是版本号。改 `main` 只影响引用 `@main` 的项目。要发新版本号，让业务项目改引用。

## 权限相关

| 症状 | 原因 |
|---|---|
| `403 Forbidden` 访问组件 | 项目对组件仓库没有读权限 |
| `401` 拉私有镜像 | deploy token 失效 |
| 看不到 promote 按钮 | 不是 Maintainer 及以上 |

# 依据

路径相对 `platform/devops/cicd/moying-cicd`，行号取 2026-11-11 的 `main` 分支。

## 已验证

| 结论 | 依据 | 类型 |
|---|---|---|
| 模板共 23 个 | `templates/*.yml` 计数 | 文件 |
| 各模板的 tag 正则不统一（9 种） | 逐文件 `grep -n "CI_COMMIT_TAG =~" templates/*.yml` | 代码 |
| Go 全家桶用 `(alpha\|test\|rc)` | `templates/backend-go-service.yml:48` | 代码 |
| JVM 全家桶用 `(alpha\|beta)` | `templates/backend-jvm-service.yml:61` | 代码 |
| `sonar-scan` 只接受 alpha | `templates/sonar-scan.yml` 的 rules | 代码 |
| `upload-artifact` 只接受 rc | `templates/upload-artifact.yml` 的 rules | 代码 |
| `docker-promote` 是手动 job，做 pull/tag/push | `templates/docker-promote.yml` | 代码 |
| 六个 stage 的顺序 | `templates/backend-go-service.yml:50-57` | 代码 |
| 默认 runner 标签 `shell`、`ci-02` | `templates/backend-go-service.yml` 的 `default.tags` | 代码 |
| `deploy-test` 实际执行 `dcli rt -e ... -s ... -t ... -r ... -o` | `templates/dcli-deploy.yml:31-40` | 代码 |
| 模板内部引用 `dcli-deploy@main`、`ai-code-review@main` | `templates/backend-go-service.yml:141-145` | 代码 |
| 组件路径含 `cicd/` 段 | `entry/with-ai-review.yml:10`、仓库 remote 地址 | 代码 |
| 组件库本身没有 `.gitlab-ci.yml`，靠 tag 发布 | 仓库根目录无该文件 | 文件 |
| `go-code-scan` 带 `allow_failure: true` | `templates/backend-go-service.yml:90` | 代码 |

## 未验证 / 需要确认

| 结论 | 状态 | 怎么确认 |
|---|---|---|
| 项目锁 `@1.2.0` 后改 main 不生效 | 基于 GitLab 组件按 ref 解析的行为，未在实例上复现 | 在测试项目改 `main` 观察下一次流水线 |
| 删 tag 重打后 GitLab 仍用旧解析 | 同上，官方文档提到缓存，未实测 | 在测试项目试一次 |
| 各业务项目当前的 `image_name`、`deploy_service_name` | 不在组件库内 | 看各项目 `.gitlab-ci.yml` |
| `sonar-scan` 在哪些项目里被覆盖成阻断 | 未知 | 搜各项目 CI 配置 |
| runner 实际挂的标签名 | 钉钉文档写 `ci-02-shell`，模板要 `shell`+`ci-02`，两者对不上；流水线能跑说明 runner 上有模板要的标签 | 到 CI-2（10.10.30.197）上 `cat /etc/gitlab-runner/config.toml` 看 tags |

## 引用来源

- 仓库：`git@gitlab.moyingrobotics.com:platform/devops/cicd/moying-cicd.git`，分支 `main`，最后提交 2026-11-04
- 交接文档：`04-手册/03-moying-cicd.md`、`06-发版SOP.md`

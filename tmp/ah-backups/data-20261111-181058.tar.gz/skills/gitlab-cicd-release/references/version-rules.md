# 逐模板的 tag 正则

`moying-cicd` 的 23 个模板用了 9 种不同的 `CI_COMMIT_TAG =~` 正则。**没有"全局统一的正则"**，这一点和早期文档写的不一样。

## 实测对照表

来自 `templates/*.yml`，取每个文件里第一条 `CI_COMMIT_TAG =~`：

| 模板 | 正则 | 接受的类型 |
|---|---|---|
| `backend-go-service` | `^\d+\.\d+\.\d+-(alpha\|test\|rc)\.\d+$` | alpha / test / rc |
| `dcli-deploy` | 同上 | alpha / test / rc |
| `backend-jvm-service` | `^\d+\.\d+\.\d+-(alpha\|beta)\.\d+$` | alpha / beta |
| `frontend-node-app` | 同上 | alpha / beta |
| `go-unit-test` / `go-integration-test` / `go-code-scan` | 同上 | alpha / beta |
| `ros2-full-build` | 同上 | alpha / beta |
| `docker-build-push` | `^\d+\.\d+\.\d+-(alpha\|beta\|test\|rc)\.\d+$` | 全部四种 |
| `docker-promote` | 同上 | 全部四种 |
| `promote-and-upload-release` | `^\d+\.\d+\.\d+-(alpha\|beta\|rc)\.\d+$` | alpha / beta / rc |
| `static-site-app` | 同上 | alpha / beta / rc |
| `sonar-scan` | `^\d+\.\d+\.\d+-alpha\.\d+$` | 只有 alpha |
| `upload-artifact` | `^\d+\.\d+\.\d+-rc\.\d+$` | 只有 rc |
| `android-apk-app` | `^\d+\.\d+\.\d+([-+][0-9A-Za-z.-]+)*$` | 任意后缀 |
| `docker-mirror` | `$[[ inputs.tag_pattern ]]` | 由 input 决定 |
| `ai-code-review` / `artifact-notify-dingtalk` / `electron-linux-app` / `go-test` / `node-*` | 无 | 不单独触发 |

## 为什么会有这种事

模板是分人、分批加的，早期 Go 全家桶定的是 alpha/test/rc，后来 JVM 和前端模板各自写了自己的正则。没有统一过。

改模板前先 `grep -n "CI_COMMIT_TAG =~" templates/<模板>.yml`，不要照抄别的模板。

## 触发矩阵（以 Go 全家桶为例）

| 触发 | 做什么 | 不做什么 |
|---|---|---|
| MR | 单测、集成测试、code-scan | 不构建、不发镜像 |
| `1.0.0-test.1` | 质量检查 + 构建 test 镜像 | 不自动出正式镜像 |
| `1.0.0-rc.1` | 质量检查 + 构建 rc 镜像 | 同上 |
| `1.0.0-beta.1` | **什么也不做**（正则不匹配） | — |
| 手动 `docker-promote` | 当前 tag 镜像 → 裸版本镜像 | — |
| 裸版本 `1.0.0` | 不触发 | 没有单独的 promote 流水线 |

JVM 服务把 test 和 beta 对调：beta 触发、test 不触发。

## 裸版本镜像怎么来的

```bash
docker pull  <image>:1.2.0-rc.1
docker tag   <image>:1.2.0-rc.1  <image>:1.2.0
docker push  <image>:1.2.0
```

正式镜像和 rc 镜像字节一致。排查「正式版行为和 rc 不一样」时，先怀疑部署的不是这个镜像。

## 组件版本

- 组件按 git tag 解析，没有构建产物；
- tag 不能重打，GitLab 有缓存；
- tag 推上去立即生效，没有灰度。

---
name: gitlab-cicd-release
description: 业务服务发版、打 tag、镜像 promote、升级 CI 组件版本时使用。触发场景：用户说"发版"、"打个 tag"、"发布到测试"、"promote 到正式"、"CI 不生效"、"组件升级到 1.x"、"流水线没触发"、"镜像没推上去"。覆盖 moying-cicd 组件库的用法和它自身的发版方式。
license: Proprietary. See LICENSE in the repository root.
metadata:
  owner: donglai.ye
  version: 1.1.0
  updated: "2026-11-11"
  source: platform/devops/cicd/moying-cicd
---

# GitLab CI/CD 发版

## 版本格式

```text
预发布：<major>.<minor>.<patch>-<预发布类型>.<N>     例：1.2.0-rc.1
正式：  <major>.<minor>.<patch>                       例：1.2.0
```

不带 `v` 前缀，`v1.2.0` 和 `1.2.0` 是两个不同的引用。

## 先确认目标模板接受哪种预发布 tag

**每个模板的正则不一样**，打之前看目标模板里那条 `CI_COMMIT_TAG =~`：

| 模板 | 接受的预发布类型 |
|---|---|
| `backend-go-service`、`dcli-deploy` | alpha / test / rc |
| `backend-jvm-service`、`frontend-node-app`、`go-unit-test`、`go-integration-test`、`go-code-scan`、`ros2-full-build` | alpha / beta |
| `docker-build-push`、`docker-promote` | alpha / beta / test / rc |
| `promote-and-upload-release`、`static-site-app` | alpha / beta / rc |
| `sonar-scan` | 只有 alpha |
| `upload-artifact` | 只有 rc |
| `android-apk-app` | 任意后缀（`[-+]xxx`） |

后果很具体：Go 后端打 `1.2.0-beta.1` **不触发**构建，打 `1.2.0-test.1` 才触发；JVM 服务反过来，beta 触发、test 不触发。

拿不准就查：

```bash
grep -n "CI_COMMIT_TAG =~" <项目>/.gitlab-ci.yml
# 或者看组件模板源文件
grep -rn "CI_COMMIT_TAG =~" moying-cicd/templates/backend-go-service.yml
```

## 发版步骤

```bash
# 1. 确认在 main 且干净
git status && git log --oneline -1

# 2. 看上一个版本，别重号
git tag --sort=-v:refname | head -5

# 3. 打预发布 tag（类型要和模板匹配，见上表）
git tag 1.2.0-rc.1 && git push origin 1.2.0-rc.1

# 4. 等流水线：unit-test → integration-test → code-scan → build
# 5. 手动点 deploy-test，部署测试环境
# 6. 手动点 docker-promote，把 1.2.0-rc.1 提升成 1.2.0
```

promote 只是把 rc 镜像重新打 tag 再 push，**不重新构建**。rc 验证过的就是正式镜像。

## 验证镜像真的上去了

不要只看 CI 绿：

```bash
curl -k -u "$REG_USER:$REG_PASS" \
  "https://images.moyingrobotics.com/v2/<group>/<project>/tags/list"

docker pull images.moyingrobotics.com/<group>/<project>:1.2.0
docker inspect --format '{{.Architecture}} {{.Size}}' \
  images.moyingrobotics.com/<group>/<project>:1.2.0
```

`CI 绿但镜像没有` 多半是 runner 的 docker login 过期，日志里搜 `unauthorized`。

## 部署到测试环境

流水线里的 `deploy-test` 实际执行：

```bash
dcli rt -e test -s <service_name> -t <tag> -r 1 -o
```

- `-s` 是 `dcli.yml` 里定义的服务名，**不是镜像名**，写错会报服务不存在；
- `-t` 就是 tag，所以只能部署预发布 tag，部署不了 `1.2.0` 正式版；
- `-o` 是 `link_cloud`，默认开。

## 流水线没触发 / 不生效

按顺序查，别猜：

1. tag 类型去对上面的表；
2. 组件版本变了没：项目锁着 `@1.2.0`，你改 `main` 对它没影响，要发新版本号；
3. runner 标签：要能匹配带 `shell` 和 `ci-02` 的 runner，否则一直 pending、不报错。注意钉钉资产文档里写的是 `ci-02-shell`/`ci-02-docker`，和模板对不上——**新 runner 按模板的 `shell` + `ci-02` 挂**，别照文档挂，否则 job 永远排不上；
4. `stages` 少一个：报 `stage does not exist`，错误藏在 job 详情里；
5. component 路径必须带 `cicd/`：`platform/devops/cicd/moying-cicd/<模板>@<版本>`。

展开后的真实配置在：Pipelines → 某个 job → 右上角 `View full configuration`。

更多排障见 [references/troubleshooting.md](references/troubleshooting.md)。

## 组件库自己发版

`moying-cicd` 没有 `.gitlab-ci.yml`，发版就是打 tag：

```bash
cd moying-cicd && git checkout main && git pull
git tag 1.4.0 && git push origin 1.4.0
```

然后业务项目把 `@1.3.0` 改成 `@1.4.0`。推上去立刻生效，没有灰度——改之前先在测试项目验证。

## 风险：模板里写死了 @main

多个模板硬编码了 `dcli-deploy@main`、`ai-code-review@main`。业务项目锁版本也锁不住它们。

改这两个文件前必须提醒用户：**这是全公司下一次跑流水线就生效的改动**。

## 回滚

```bash
# 单个服务
kubectl -n moying-business rollout undo deployment/<service>

# 整个 release
helm history moying-cloud -n moying-business
helm rollback moying-cloud <revision> -n moying-business
```

带数据库迁移的版本回不去，发之前必须备份。

## 别做

- 不要删 tag 重打：GitLab 会缓存组件解析结果，改了不生效，要发新版本号。
- 不要手工 `docker tag/push` 正式版本镜像：来源不可查。
- 不要用正式 tag 部署测试环境：规则不允许，硬改会绕过质量门。
- 不要改 `values.generated.yaml` 当永久配置：下次跑脚本会被覆盖。
- 不要假设所有模板都认同一个 tag：见上面的表。

## 深入

- [references/version-rules.md](references/version-rules.md)：逐模板的 tag 正则与触发矩阵
- [references/templates.md](references/templates.md)：23 个组件模板逐个说明
- [references/troubleshooting.md](references/troubleshooting.md)：流水线不触发、镜像不上、权限问题
- [references/evidence.md](references/evidence.md)：每条结论的出处

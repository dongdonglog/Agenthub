---
name: k8s-business-release
description: 业务服务在 K3s 上发版、跑数据库迁移、回滚时使用。触发场景：用户说"发个工作台"、"数字造机上线"、"migrate job 失败"、"滚动更新卡住"、"rollout undo"、"32222 打不开"、"Secret 怎么配"。覆盖 k8s 仓库两条业务线的清单结构、发版顺序和已知不一致。
license: Proprietary. See LICENSE in the repository root.
metadata:
  owner: donglai.ye
  version: 1.0.0
  updated: "2026-11-11"
  source: platform/devops/k8s
---

# 业务 K8s 发版

## 先确认什么

1. **哪条业务线**：墨影工作台（Go + Next.js）还是数字造机（Spring Boot + Next.js）。
2. **带不带数据库迁移**：带就必须先备份，迁移回不去。
3. **在哪个集群**：脚本默认 `SSH=moying@10.10.30.193`，本地 kubectl 要设 `USE_SSH=0`。

## 两条线的基本盘

| | 墨影工作台 | 数字造机 |
|---|---|---|
| 命名空间（清单里写的） | `moying-workbench`（前端）/ `moying-robot-workbench`（后端） | `moying-robot-workbench` |
| 后端 Service | LoadBalancer 8080 → nodePort **31947** | NodePort 80 → nodePort **32222** |
| 前端 nodePort | **31945** | **30652** |
| 探针 | `/readyz`、`/healthz` | startup / readiness / liveness 三探针 |
| 迁移 | golang-migrate Job `moying-workbench-migrate` | 清单里没有独立迁移 Job |

命名空间本身就不统一：工作台前端写 `moying-workbench`，后端和数字造机写 `moying-robot-workbench`。apply 之前先看目标文件的 `metadata.namespace`，不要假设。

## 发版顺序

```text
备份 → 删旧 migrate Job → apply 新 Job（同镜像）→ 等 Job Complete
→ 换 Deployment 镜像 → 等 rollout → 探针通过 → 验证接口 → 失败则回滚
```

| 步 | 命令 | 成功判据 |
|---|---|---|
| 1 | 备份数据库 | 备份文件存在且大小正常 |
| 2 | `kubectl -n <ns> delete job moying-workbench-migrate --ignore-not-found` | Job 不存在 |
| 3 | `kubectl -n <ns> apply -f migrate-job.yaml` | `kubectl get job` 显示 `COMPLETIONS 1/1` |
| 4 | 改 Deployment 镜像 tag | `kubectl -n <ns> set image deploy/<name> <container>=<image>` |
| 5 | `kubectl -n <ns> rollout status deploy/<name>` | 输出 `successfully rolled out` |
| 6 | 探针 | `kubectl get pod` 全 `1/1 Running` |
| 7 | 接口 | `curl` 关键路径返回 200 |

Job 名是固定的，**apply 之前必须先删**，否则 `apply` 会报 `field is immutable`。

迁移镜像**必须和 Deployment 用同一个 tag**：migrate 的 SQL 在镜像里的 `/app/migrations`，镜像里还要有 `/usr/local/bin/migrate`。用错版本等于用旧 SQL 改新库。

## 用封装脚本（推荐，默认 dry-run）

```bash
# 只打印计划，不改集群
./deploy/k8s/upgrade-workbench.sh

# 真执行
APPLY=1 ./deploy/k8s/upgrade-workbench.sh

# 指定镜像 / 跳过迁移 / 改目标机
APPLY=1 IMAGE=images.moyingrobotics.com/moying/moying-workbench:1.0.0-alpha.17 \
  ./deploy/k8s/upgrade-workbench.sh
SKIP_MIGRATE=1 APPLY=1 ./deploy/k8s/upgrade-workbench.sh
SSH=moying@10.10.30.193 APPLY=1 ./deploy/k8s/upgrade-workbench.sh
USE_SSH=0 APPLY=1 ./deploy/k8s/upgrade-workbench.sh
```

其它可调变量：`NS`、`DEPLOY`、`MIGRATE_TIMEOUT`（默认 180s）。

`SKIP_MIGRATE=1` 只在一个前提下能用：**确认库里 schema 已经是目标版本**。不确定就老实跑迁移。

只读巡检用 `preflight-workbench.sh`，它不改任何东西。

## 回滚

```bash
kubectl -n <ns> rollout undo deployment/<name>
kubectl -n <ns> rollout status deployment/<name>
```

**迁移不能回滚。** `migrate up` 之后没有 down 脚本就退不回去。顺序是：先停新版本 → 确认旧版本能配新表 → 不行就恢复备份。

## 已知坑

1. **数字造机的 Service selector 写错**：Service 选 `app.kubernetes.io/name: moying-moying-robot-workbench`，Deployment 的 Pod 标签是 `digital-machine-creation`，选不中。表现为 32222 能连但没后端。
2. **命名空间混用**：工作台前端在 `moying-workbench`，后端在 `moying-robot-workbench`。`-n` 写错就是 `NotFound`。
3. **`secret.yaml` 是真实密钥且已提交**：换环境时不要直接 apply，先按 `secret.example.yaml` 生成新的。轮换步骤见交接文档 05 台账。
4. **`imagePullSecrets: moying-registry` 必须存在**：新集群没建这个 secret，Pod 会 `ImagePullBackOff`。
5. **探针路径因服务而异**：工作台是 `/readyz`、`/healthz`；数字造机是 Spring Boot 的 actuator 路径。改端口或 context-path 时探针要一起改。
6. **脚本默认连的是测试机**：`upgrade-workbench.sh` 默认 `SSH=moying@10.10.30.193`（研发测试环境），生产在 `10.10.30.133`。直接跑默认值等于在测试环境发版，`APPLY=1` 之前先看 `SSH` 对不对。

## 别做

- 不要在没备份的库上跑迁移。
- 不要用 `kubectl edit` 改线上 Deployment：下次 apply 会被覆盖。
- 不要跳过 migrate 直接换镜像，除非确认 schema 已是最新。
- 不要把 `secret.yaml` 推到公开仓库或贴进聊天。

## 深入

- [references/manifests.md](references/manifests.md)：两条线的对象清单、端口、命名空间
- [references/evidence.md](references/evidence.md)：每条结论的出处

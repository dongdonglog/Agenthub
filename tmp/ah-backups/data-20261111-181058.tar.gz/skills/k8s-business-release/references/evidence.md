# 依据

路径相对 `platform/devops/k8s/moying-robot-workbench/`，行号取 2026-11-11 的 `main` 分支（最后提交 7fe8ccd，2026-08-31）。

## 已验证

| 结论 | 依据 | 类型 |
|---|---|---|
| 迁移 Job 名固定 `moying-workbench-migrate` | `墨影工作台/后端/migrate-job.yaml:16` | 代码 |
| `backoffLimit: 1`、`ttlSecondsAfterFinished: 86400` | 同上 `:22-23` | 代码 |
| 迁移镜像必须与 Deployment 同 tag，SQL 在 `/app/migrations`，需要 `/usr/local/bin/migrate` | `migrate-job.yaml:4-10`（文件头注释） | 代码 |
| 脚本默认 dry-run，`APPLY=1` 才执行 | `upgrade-workbench.sh:5,28` | 代码 |
| 默认 `NS=moying-workbench`、`DEPLOY=moying-workbench` | `upgrade-workbench.sh:22-23` | 代码 |
| 默认 `SSH=moying@10.10.30.193`、`USE_SSH=1` | `upgrade-workbench.sh:25,27` | 代码 |
| 支持 `SKIP_MIGRATE`、`MIGRATE_TIMEOUT` | `upgrade-workbench.sh:29-30` | 代码 |
| 工作台后端 LoadBalancer 8080 → 31947 | `墨影工作台/后端/service.yaml:15,20,22` | 代码 |
| 工作台探针 `/readyz`、`/healthz`，容器端口 8080 | `墨影工作台/后端/deployment.yaml:35,41-50` | 代码 |
| 工作台前端 nodePort 31945，namespace `moying-workbench` | `墨影工作台/前端/web.yaml:5,81` | 代码 |
| 数字造机 Service 名/selector 为 `moying-moying-robot-workbench`，nodePort 32222 | `数字造机/后端/service.yaml:5,15` | 代码 |
| 数字造机 Deployment Pod 标签是 `digital-machine-creation`（与 Service 不匹配） | `数字造机/后端/deployment.yaml:18-22` | 代码 |
| 数字造机 namespace `moying-robot-workbench` | `数字造机/后端/namespace.yaml`、`deployment.yaml:5` | 代码 |
| 数字造机 PDB `minAvailable: 1` | `数字造机/后端/pod-disruption-budget.yaml:6` | 代码 |
| `secret.yaml`、`secrets.yaml` 已提交且含真实值 | `git ls-files` + 文件内容 | 代码 |
| 10.10.30.133 是数字造机生产机，workbench/machine/robot/auth 都落在这 | 钉钉《整理公司域名的服务和网络拓扑结构》 | 文档 |
| `upgrade-workbench.sh` 默认 SSH 指向 193（研发测试），不是生产 133 | `upgrade-workbench.sh:25` + 上方拓扑文档 | 代码 + 文档 |

## 未验证

| 结论 | 状态 | 怎么确认 |
|---|---|---|
| 集群里实际 namespace 到底是哪个 | 清单里就有两种写法 | `kubectl get ns`、`kubectl -n <ns> get deploy` |
| 数字造机 32222 是否真的打不通 | 从 selector 代码推断，未实测 | `kubectl get endpoints moying-moying-robot-workbench -n moying-robot-workbench`，看是否为空 |
| 工作台后端在 `moying-workbench` 还是 `moying-robot-workbench` | 清单与脚本不一致 | 同上 |
| `imagePullSecrets: moying-registry` 是否存在 | 清单引用了，集群里是否有未知 | `kubectl get secret moying-registry -n <ns>` |

## 引用来源

- 仓库：`git@gitlab.moyingrobotics.com:platform/devops/k8s.git`，分支 `main`
- 交接文档：`04-手册/08-k8s.md`

# 清单与端口

路径相对 `platform/devops/k8s/moying-robot-workbench/`。

## 墨影工作台

```text
墨影工作台/
├── 后端/
│   ├── deployment.yaml          replicas=2，容器端口 8080，探针 /readyz /healthz
│   ├── service.yaml             LoadBalancer 8080 → nodePort 31947
│   ├── configmap.yaml           非敏感配置（DB host/port/name、Aptly、超时、日志格式）
│   ├── secret.example.yaml      Secret 模板，值为 change-me
│   ├── secret.yaml              真实 Secret（已提交，必须轮换）
│   ├── migrate-job.yaml         Job moying-workbench-migrate，golang-migrate
│   ├── preflight-workbench.sh   只读巡检
│   └── upgrade-workbench.sh     升级封装，默认 dry-run
└── 前端/
    └── web.yaml                 Deployment + LoadBalancer，nodePort 31945
```

## 数字造机

```text
数字造机/
├── 后端/
│   ├── namespace.yaml           Namespace moying-robot-workbench
│   ├── deployment.yaml          Spring Boot，三探针，非 root，带 securityContext
│   ├── service.yaml             NodePort 80 → 32222
│   ├── configmap.yaml           JDBC URL、MinIO、工作台回调、JVM 参数
│   ├── secrets.yaml             真实 Secret（已提交）
│   └── pod-disruption-budget.yaml  minAvailable 1
└── 前端/
    └── digital-machine-creation-web.yaml   ConfigMap + Deployment + Service，nodePort 30652
```

## 端口总表

| 服务 | 类型 | 端口 | nodePort |
|---|---|---|---|
| 工作台后端 | LoadBalancer | 8080 | 31947 |
| 工作台前端 | LoadBalancer | 80 | 31945 |
| 数字造机后端 | NodePort | 80 | 32222 |
| 数字造机前端 | LoadBalancer | 80 | 30652 |

## 已知不一致

| 现象 | 证据 | 影响 |
|---|---|---|
| 数字造机 Service 名与 selector 都是 `moying-moying-robot-workbench`，Deployment Pod 标签是 `digital-machine-creation` | `数字造机/后端/service.yaml:5-9` vs `deployment.yaml:18` | Service 选不到 Pod，32222 无后端 |
| 工作台前端 namespace 是 `moying-workbench`，后端是 `moying-robot-workbench` | `前端/web.yaml:5` vs `后端/service.yaml:5` | `-n` 写错就 NotFound |
| 脚本默认 `NS=moying-workbench`，后端清单写 `moying-robot-workbench` | `upgrade-workbench.sh` 默认值 vs `deployment.yaml:5` | 用脚本时要么传 `NS`，要么确认后端真的在前者 |

这三条都要在现场用 `kubectl -n <ns> get all` 复核一遍再改，别照着清单猜。

## 迁移 Job 要点

- Job 名固定 `moying-workbench-migrate`，重跑前必须 `delete job`；
- 镜像 tag 必须与随后要发布的 Deployment 一致（SQL 在镜像里）；
- 优先用 Secret 的 `DATABASE_DSN`；没有就用 ConfigMap 的 host/port/name + Secret 的 user/password 拼；
- `backoffLimit: 1`，失败一次就停，不会无限重试；
- `ttlSecondsAfterFinished: 86400`，一天后自动清理。

---
name: tiangong-troubleshoot
description: 排查天工现场部署和运行故障时使用。触发场景：用户贴出报错、说"装不上"、"卡在下载"、"退出码 78/79"、"Pod 起不来"、"ImagePullBackOff"、"CrashLoopBackOff"、"业务连不上数据库"、"MetalLB 没 IP"、"Gitea 推不上去"、"证书过期"、"磁盘满"、"日志查不到"。按症状给排查顺序，不按服务名。
license: Proprietary. See LICENSE in the repository root.
metadata:
  owner: donglai.ye
  version: 1.0.1
  updated: "2026-11-11"
  source: platform/devops/online-install
---

# 天工故障排查

## 先做三件事

不要一上来就猜。这三条能排掉一半：

```bash
date -u                                        # 时间偏差 → TLS 全失败
df -h /                                        # 磁盘满 → 各种奇怪错误
curl -kI https://nexus.moyingrobotics.com      # 网络通不通
```

## 定位到层

```text
能 SSH 吗？
├─ 不能 → 网络 / 机器本身（客户或机房）
└─ 能 → systemctl 里中间件活着吗？
   ├─ 大面积 dead → 宿主机层（prepare:system / playbook）
   └─ 活着 → kubectl 能用吗？
      ├─ 不能 → K3s 层（k3s.yml / k3s_autofix）
      └─ 能 → Pod 什么状态？
         ├─ ImagePullBackOff → 镜像层（Nexus / registry / EULA）
         ├─ CrashLoopBackOff → 应用层（看日志）
         └─ Running 但业务不通 → 网络层（Endpoints / MetalLB）
```

## 症状速查

| 看到的 | 先跑这个 | 大概率原因 |
|---|---|---|
| 卡在下载 / `Failed to fetch` / 证书错误 | `date -u; timedatectl status` | 时钟没同步 |
| 退出码 78 | `grep -E "78\|kernel\|mongodb" .generated/*.log \| tail` | 内核或 MongoDB 前置不满足 |
| 退出码 79 | — | 需要重启，重启后用原命令重跑 |
| `dpkg: error processing package mongodb-org` | `uname -r` | 7.0.0-30 类内核 ABI 不匹配 |
| `Skipping push ... repo not ready` | `kubectl -n middleware get pod \| grep gitea` | Gitea 没起来，先看 PG |
| `EXTERNAL-IP: pending` | `kubectl get ipaddresspool -n metallb-system -o yaml` | 地址池和机器不同网段 |
| `ImagePullBackOff` + `401` | — | Nexus EULA 没接受 / 登录过期 |
| `manifest unknown` | `curl` 镜像仓库 tags | 现场仓库没同步到这个 tag |
| `x509: certificate signed by unknown authority` | — | 自签证书没进 insecure-registries |
| `CrashLoopBackOff` | `kubectl logs <pod> --previous --tail=200` | 启动就退：配置/依赖；跑一会儿退：OOM |
| Pod Running 但业务不通 | `kubectl -n moying-business get endpoints <svc>` | Endpoints 为空 = 没打通 |
| 证书过期 | `openssl s_client -connect host:443 \| openssl x509 -noout -dates` | 证书到期 |
| 日志查不到 | `curl -s http://host:9428/select/logsql/query -d 'query=*' \| head -3` | 采集没上来，或时区差 8 小时 |
| LDAP 登不进 | `kubectl logs <ldap-pod> --tail=200 \| grep -i sync` | 钉钉事件没到 / OU 不匹配 / 下游没同步 |

完整命令和判断分支见 [references/symptoms.md](references/symptoms.md)。

## 三条硬规则

1. **退出码 78/79 不是失败**。78 是前置没满足，79 是等重启。不要建议重装。
2. **先定位阶段，再决定重跑什么**。`tiangong.sh` 支持分阶段（`--middleware-only` / `--apps-only` / `--post-mirror`），从头发车是最后手段。
3. **生产环境先问备份**。涉及数据目录、迁移、重装的动作，先确认备份存在且演练过。

## 别做

- `dpkg -i --force-all`、`apt --allow-unauthenticated`：包装上了，数据会写坏。
- `imagePullPolicy: Never` 加手工 load 镜像：能跑，下次升级必炸。
- 删 `.generated/`、`anything/`、数据库数据目录当"清理"。
- 直接 `git pull` 更新现场部署脚本：版本对不上。
- 备份放 `/tmp`：重启就没了。

## 备份与恢复

| 数据 | 备份 | 恢复 |
|---|---|---|
| MongoDB | `backup_core_exclude.sh` → `/tmp/mongo_backup` | `mongorestore` |
| PostgreSQL | `pg_dump -Fc` | `pg_restore` |
| K3s | `k3s etcd-snapshot` | 快照恢复 |

没演练过的备份等于没有备份。细节和命令见 [references/backup-restore.md](references/backup-restore.md)。

## 深入

- [references/symptoms.md](references/symptoms.md)：每个症状的完整排查链
- [references/backup-restore.md](references/backup-restore.md)：备份、恢复、演练
- [references/evidence.md](references/evidence.md)：每条结论的出处与未验证项

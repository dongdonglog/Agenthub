# 备份与恢复

现场最不能丢的是数据。中间件可以重装，数据不行。

## 备份矩阵

| 数据 | 位置 | 备份方式 | 频率 | 恢复方式 |
|---|---|---|---|---|
| MongoDB | 宿主机 `/var/lib/mongodb` | `common-shell/backup_core_exclude.sh` | 每天 | `mongorestore` |
| PostgreSQL | 宿主机 `pgdata` | `pg_dump -Fc` | 每天 | `pg_restore` |
| MinIO | 宿主机数据目录 | 目录级同步 | 按客户要求 | 目录回拷 |
| K3s etcd | `/var/lib/rancher/k3s` | `k3s etcd-snapshot` | 每天 | 快照恢复 |
| 配置仓库 | 现场 Gitea | Gitea 自带备份 | 每周 | 仓库导入 |

## MongoDB

```bash
# 备份（脚本里排除大集合，输出到 /tmp/mongo_backup）
./backup_core_exclude.sh
ls -lh /tmp/mongo_backup/

# 恢复
mongorestore --uri "mongodb://<user>:<pass>@<host>:27017/<db>?authSource=admin" \
  --gzip --archive=/path/to/backup.gz
```

**`/tmp` 会被系统清**。备份放 `/tmp` 只是临时手段，必须改成挂载盘或对象存储。

## PostgreSQL

```bash
# 备份
pg_dump -Fc -h <host> -U <user> -d <db> -f /backup/<db>-$(date +%F).dump

# 恢复（先建空库）
pg_restore -h <host> -U <user> -d <db> --clean --if-exists /backup/<db>.dump
```

## K3s

```bash
# 手动快照
k3s etcd-snapshot save --name manual-$(date +%F)

# 查看已有快照
k3s etcd-snapshot list

# 恢复（会重启集群，慎用）
systemctl stop k3s
k3s server --cluster-reset --cluster-reset-restore-path=<snapshot>
systemctl start k3s
```

恢复 etcd 会把整个集群状态回退到快照时间点，业务数据不在此列。做之前先确认影响范围。

## 演练

交接期内至少做一次：

1. 把最新备份恢复到测试库；
2. 起一个服务连上去，确认数据在；
3. 记录耗时。

没演练过的备份等于没有备份——文件可能一直是空的、或者早就不跑了。

## 恢复前的三个问题

1. **要回到哪个时间点**？备份不是连续的，最近一次备份之后的数据就是丢了。
2. **业务能接受停机多久**？恢复期间服务不可用。
3. **有没有依赖恢复顺序**？先数据库后应用，反过来应用会起不来。

# 症状排查链

每条按「现象 → 先确认 → 分支 → 处理」写。命令可以直接复制。

## 装机阶段

### 卡在下载或装 Ansible

```text
Failed to fetch https://nexus.moyingrobotics.com/...
E: The repository ... is not signed
```

```bash
date -u
timedatectl status | head -5
curl -kI https://nexus.moyingrobotics.com/repository/ubuntu/devops/
```

| 结果 | 处理 |
|---|---|
| 时间偏差 > 5 分钟 | `sudo bash sh/bootstrap-clock.sh`，同步完重跑 |
| curl 证书错误 | 要么时间错，要么客户做了 TLS 拦截，要例外 |
| curl 超时 | 客户出网策略没开，白名单 `nexus.moyingrobotics.com:443` |

### 退出码 78 / 79

| 码 | 含义 | 处理 |
|---|---|---|
| 78 | 前置条件 / 升级未完成 | 看脚本最后打印的提示，通常是内核或 MongoDB |
| 79 | 需要重启或已提交重启 | 重启后用原命令原参数重跑 |
| 130/143 | 被 Ctrl-C / SIGTERM | 直接重跑 |

```bash
grep -E "78|79|kernel|mongodb" .generated/*.log 2>/dev/null | tail -30
```

### Ubuntu 26.04 装 MongoDB 失败

```text
dpkg: error processing package mongodb-org (--configure)
```

原因：7.0.0-30 这类内核 ABI 与官方包不匹配。

处理：`middleware-preflight.yml` 会先检查并退出 78，按提示装 `linux-generic` 新内核再重启。装完新内核**没切过去**也不行，`uname -r` 必须是新内核。

### Gitea 推送失败

```bash
kubectl -n middleware get pod | grep gitea
curl -kI http://<gitea>:31914/
```

Gitea 依赖 PostgreSQL，PG 没起来 Gitea 也起不来。先看 PG。

### MetalLB 没分到 IP

```bash
kubectl -n metallb-system get pod
kubectl get svc -A | grep -i pending
kubectl -n metallb-system get ipaddresspool -o jsonpath='{.items[*].spec.addresses}'
ip -4 addr | grep inet
```

`EXTERNAL-IP` 一直 pending，基本是地址池和机器不在同一段。改 `metallb/templates/metallb-address-pool.yaml` 后重跑。

## 运行阶段

### ImagePullBackOff

```bash
kubectl -n moying-business describe pod <pod> | tail -25
```

| Events | 原因 | 处理 |
|---|---|---|
| `401 Unauthorized` | 登录过期 / EULA 没接受 | 单独跑 `--post-mirror`，或手工 `docker login` |
| `manifest unknown` | 现场仓库没这个 tag | 确认 `--post-mirror` 跑过 |
| `no such host` | DNS 解析不到 | 检查 `/etc/hosts` 或 CoreDNS |
| `x509: certificate signed by unknown authority` | 自签证书 | 配 `insecure-registries` 或装 CA |

### CrashLoopBackOff

```bash
kubectl -n moying-business logs <pod> --previous --tail=200
kubectl -n moying-business describe pod <pod> | grep -A5 "Last State"
```

- 启动就退出：配置错或依赖没通，看日志第一屏（多连不上数据库/Redis）；
- 跑一会儿退出：OOM 或探针打挂，看 `Last State` 的 `Reason`。

### Pod Running 但业务不通

按顺序：

```bash
# 1. Endpoints 有没有
kubectl -n moying-business get svc,endpoints <service>

# 2. Endpoints 地址对不对
kubectl -n moying-business get endpoints <service> -o yaml

# 3. Pod 内能不能连宿主机中间件
kubectl -n moying-business exec -it <pod> -- sh -c \
  "nc -zv <mongo-host> 27017; nc -zv <pg-host> 5432; nc -zv <redis-host> 6379"

# 4. 宿主机监听了吗
ss -lntp | grep -E "27017|5432|6379"
```

1 空 → `apply_svc_endpoints` 没跑或 inventory 没填，重跑 `--apps-only`。
3 不通但 4 在听 → 防火墙，或监听地址是 `127.0.0.1`（改 `bindIp`）。

### 证书过期

```bash
echo | openssl s_client -connect gitlab.moyingrobotics.com:443 2>/dev/null | \
  openssl x509 -noout -dates
```

GitLab 证书过期会连带 runner 拉不了代码，报错像网络问题（`SSL certificate problem`），先看这句。

### 磁盘满

```bash
df -h
du -sh /var/log/* 2>/dev/null | sort -h | tail -10
du -sh /opt/* 2>/dev/null | sort -h | tail -10
```

三个常见占位：

- journal：`journalctl --vacuum-size=2G`
- 镜像层：`k3s crictl rmi --prune`
- 数据目录：`/var/lib/...`，别手删，走备份和归档

### LDAP 登不进 / 入职没同步

```bash
kubectl -n <ns> get pod | grep ldap
kubectl -n <ns> logs <pod> --tail=200 | grep -iE "sync|error|fail"
```

| 情况 | 处理 |
|---|---|
| 钉钉没发事件 | 查钉钉开放平台应用权限和回调地址 |
| 收到了但同步失败 | 日志里有 DN / OU 错误，按错误改映射 |
| 同步成功但登不进 | 密码策略或下游（禅道/TAPD）没同步 |

紧急恢复：全量同步幂等，等整点兜底或手工触发一次，但先确认不会把测试账号删掉。

## 找谁

| 症状 | 找 |
|---|---|
| 机器连不上、网络策略 | 客户 IT / 机房 |
| GitLab 权限、runner | GitLab 管理员 |
| Nexus、镜像仓库 | 平台组 |
| 钉钉应用、组织架构 | 行政 / IT |
| 业务代码本身 | 对应研发 |

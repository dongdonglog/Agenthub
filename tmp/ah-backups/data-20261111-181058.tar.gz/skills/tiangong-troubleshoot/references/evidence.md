# 依据

路径相对 `platform/devops/online-install` 与其兄弟仓库。

## 已验证

| 结论 | 依据 | 类型 |
|---|---|---|
| 退出码 78/79 不是失败，且不参与重试 | `online-install/tiangong.sh:88-94`、`online-install/README.md:53` | 代码 + 文档 |
| preflight 只读且不重试 | `online-install/tiangong.sh:1603-1680` | 代码 |
| 命名空间 `middleware` / `moying-business` / `logging` | `online-install/tiangong.sh:3055` / `2837` / `3087` | 代码 |
| Gitea HTTP 端口 31914、SSH 2222 | `online-install/vars/gitea_vars.yml:14-15` | 代码 |
| VictoriaLogs 端口 9428 | `online-install/vars/victoria_logs_vars.yml:8` | 代码 |
| 日志采集是 `logging` 命名空间的 vector DaemonSet，标签 `app: vector` | `online-install/vector-vmlogs/vector.yaml:110-123` | 代码 |
| 采集写入的字段：`kubernetes.pod_namespace` / `pod_name` / `container_name`、`message` 复制到 `_msg` | `online-install/vector-vmlogs/vector.yaml:32-38` | 代码 |
| MongoDB 备份命令是 `mongodump --host --port --db --username --password --authenticationDatabase --out`，再 tar 到 `$BACKUP_DIR` | `common-shell/backup_core_exclude.sh:47-60` | 代码 |
| 备份默认输出 `/tmp/mongo_backup` | `common-shell/README.md`、脚本头部变量 | 文档 + 代码 |
| MetalLB 地址池文件路径 | `online-install/metallb/templates/metallb-address-pool.yaml` | 文件 |

## 外部资料（非本仓库）

| 结论 | 来源 |
|---|---|
| `k3s etcd-snapshot save/list` 的用法 | K3s 官方文档 <https://docs.k3s.io/datastore/backup-restore>，未在本仓库脚本里使用过 |
| `pg_dump -Fc` / `pg_restore` 参数 | PostgreSQL 官方文档，仓库里没有封装脚本 |
| `journalctl --vacuum-size`、`crictl rmi --prune` | 通用运维命令，仓库里没用过 |

这几条标注为"通用做法"，现场执行前先 `--help` 确认版本支持。

## 未验证

| 结论 | 状态 | 怎么确认 |
|---|---|---|
| 7.0.0-30 内核与 MongoDB 8.x 的 ABI 冲突细节 | 来自 `README.md` 与 preflight 的注释，没有逐台复现 | 现场 `uname -r` + 看 preflight 输出 |
| 磁盘占用最常见的三个位置 | 经验判断 | 现场 `du -sh` 实测 |
| 各现场实际端口 | 取默认值 | `ss -lntp` |

## 引用来源

- 交接文档：`07-故障处置.md`（同一套内容的完整版）

---
name: ldap-account-ops
description: 处理入职/离职账号同步、LDAP 登录异常时使用。触发场景：用户说"新人登不进"、"离职账号没停"、"钉钉改了部门没同步"、"LDAP 里查不到人"、"禅道账号不对"、"同步报错"、"改密码没生效"。覆盖钉钉 → LDAP → 禅道/TAPD 这条链路和排障顺序。
license: Proprietary. See LICENSE in the repository root.
metadata:
  owner: donglai.ye
  version: 1.0.0
  updated: "2026-11-11"
  source: platform/devops/tapd-work/moying-ldap
---

# 账号同步与 LDAP 排障

## 先分三种情况

不要直接翻日志，先判断是哪一段断了：

| 现象 | 断在哪 | 先看 |
|---|---|---|
| 钉钉里改了，LDAP 里没变 | 事件没到，或同步失败 | 服务日志里有没有收到请求 |
| LDAP 里有了，禅道/TAPD 没有 | 下游写入失败 | 日志里的禅道相关报错 |
| LDAP 里有，但登不进系统 | 密码或下游鉴权 | 条目属性和下游配置 |

## 链路

```text
钉钉组织架构
   │ 事件回调（实时）        │ 每小时全量（兜底）
   ▼                        ▼
/dingtalk/webhook  →  同步逻辑  →  OpenLDAP（inetOrgPerson / organizationalUnit）
                                    │
                                    ├→ 禅道 zt_user（入职新建、离职 deleted=1）
                                    └→ TAPD（人员/部门）
```

服务只有一个二进制，监听 `:7777`，对外通过 NodePort **31777**（`moying-ldap.yaml:87`）。OpenLDAP 自己走 `ldap-svc.yaml` 的 **30778** → 389。

## 接口

| 路径 | 谁调 | 用途 |
|---|---|---|
| `POST /dingtalk/webhook` | 钉钉 | 组织架构事件（主入口） |
| `POST /webhook` | OpenProject(PM) | 项目成员变更 |
| `POST /tapd/webhook` | TAPD | 人员变更 |
| `POST /tapd/new/webhook` | TAPD | 需求变更 |
| `GET /hour-alert/healthz` | 监控 | 健康检查 |
| `POST /hour-alert/run` | 人工 | 手动跑一次工时告警 |
| `GET /hour-alert/audit` | 人工 | 审计列表 |

## 同步是怎么触发的

1. **启动时**：先连 LDAP，再跑一次全量对齐；
2. **定时**：`SYNC_INTERVAL` 默认 1 小时，ticker 到期重连 LDAP 再全量跑一次；
3. **实时**：钉钉事件打到 `/dingtalk/webhook`，单条处理。

定时全量是兜底，**它可以修掉 webhook 丢事件造成的不一致**。所以"改了没生效"不一定有 bug，可能只是还没到整点。

## 排障顺序

```bash
# 1. 服务活着吗
kubectl -n <ns> get pod | grep ldap-dingtalk
curl -s http://<host>:31777/hour-alert/healthz

# 2. 最近有没有收到事件
kubectl -n <ns> logs <pod> --tail=200 | grep -iE "webhook|dingtalk|sync"

# 3. 这个人在 LDAP 里到底是什么状态
ldapsearch -x -H ldap://<ldap-host>:389 -D "cn=admin,dc=moyingrobotics,dc=com" -W \
  -b "dc=moyingrobotics,dc=com" "(mail=<邮箱>)"

# 4. 禅道里有没有
mysql -h <zentao-host> -u <user> -p -e \
  "select account,realname,deleted from zentao.zt_user where account='<账号>';"
```

判断：

- 3 查不到人 → 同步没执行成功，回 2 看报错；
- 3 有、4 没有或 `deleted=1` 不对 → 禅道那一段失败；
- 3 有、4 也对、人还是登不进 → 密码策略或下游系统自己的问题，不是同步的事。

## 配置

| 变量 | 作用 | 敏感 |
|---|---|---|
| `LDAP_URL` | LDAP 地址，默认 `ldap://10.10.30.118:30778` | 否 |
| `LDAP_ADMIN_DN` / `LDAP_ADMIN_PASSWORD` | 管理员绑定 | 是 |
| `LDAP_BASE_DN` | 根 DN，默认 `dc=moyingrobotics,dc=com` | 否 |
| `SYNC_INTERVAL` | 全量同步间隔，默认 `1h` | 否 |
| `ZENDAO_DB_*` | 禅道库连接 | 是 |
| `ZENDAO_REQUIRE_DEPT_MATCH` | 部门不匹配时是否拒绝建号，默认 `true` | 否 |
| `SERVER_PORT` | 监听端口，默认 `:7777` | 否 |

敏感值一律从 Secret/台账取，不要从代码里抄。

## 已知坑

1. **代码里有硬编码兜底值**：`dingtalk/config/config.go`、`ldap/config/config.go` 里带了 AppSecret 和 LDAP 管理员口令的默认值。没配环境变量时会用默认值，看起来"能跑"，实际上是共用凭证。排查鉴权问题先确认环境变量真的注入了。
2. **镜像 tag 是 `latest`**：`moying-ldap.yaml` 拉的是 `:latest`，改完代码重新 apply **不会**换镜像，要 `kubectl rollout restart`。
3. **部门不匹配就不建号**：`ZENDAO_REQUIRE_DEPT_MATCH=true` 时，钉钉部门在禅道里找不到对应，这个人不会出现在禅道。日志里能搜到 dept 相关错误。
4. **离职是软删**：禅道里 `deleted=1`，不是物理删除。查"人还在不在"要带这个条件。
5. **全量同步会覆盖人工改动**：手工在 LDAP 里加的人，下一轮全量可能被当成多余数据。要保留就加进同步规则，不要只改 LDAP。

## 别做

- 不要直接改生产 LDAP 条目来"修"数据：下一次全量会被覆盖。
- 不要用 `latest` 判断线上版本：`kubectl get pod -o jsonpath='{.spec.containers[*].image}'` 才是真的。
- 不要在没有备份的情况下跑全量同步：先确认它不会把测试账号删掉。
- 不要把 AppSecret、管理员口令贴进工单或聊天。

## 深入

- [references/sync-flow.md](references/sync-flow.md)：同步逻辑与禅道映射细节
- [references/evidence.md](references/evidence.md)：每条结论的出处

# 同步逻辑与禅道映射

## 启动顺序（`cmd/cmd.go`）

1. 连 LDAP（`EnsureConnected`），失败只打日志，不退出；
2. 起一个 goroutine：先跑一次全量，然后 `time.NewTicker(SYNC_INTERVAL)`，每次到点先重连 LDAP 再全量；
3. 注册路由；
4. `r.Run(SERVER_PORT)` 阻塞。

所以**定时全量失败不会让进程退出**，服务看起来是好的，但数据不再更新。排查"最近没人同步"要看日志里 `Scheduled LDAP sync` 那几行。

## 钉钉事件

`POST /dingtalk/webhook` 收到事件后：

1. 取出变更的用户/部门；
2. 同步到 LDAP：新增用户建 `inetOrgPerson`，部门建 `organizationalUnit`；
3. 联动禅道：`zentao.Syncer.EnsureUser`；
4. 离职走 `DeactivateUserByDingID`。

**本服务不写 `userPassword`**（全仓库没有这个字段的写入）。也就是说 LDAP 账号的密码不是这里设的，登录用哪套凭据要问下游系统，别在这里找。

## 禅道字段映射

`EnsureUser` 写入/更新 `zt_user`：

| 禅道字段 | 来源 | 说明 |
|---|---|---|
| `account` | `buildAccount(email, name, userid)` | 邮箱/姓名/钉钉 uid 推导，重名时 `makeUniqueAccount` 加后缀 |
| `realname` | 钉钉姓名 | |
| `email` | 企业邮箱优先，退个人邮箱 | 为空时不覆盖已有邮箱 |
| `mobile` | 钉钉手机号 | |
| `dingding` | 钉钉 userid | 用来反查 |
| `dept` | `resolveDeptID(deptIDList)` | 匹配不到就不写 dept（保留原值） |
| `deleted` | 固定写 `0` | 重新出现的人会被恢复 |

离职：`DeactivateUserByDingID` 把 `deleted` 置 1，不物理删除。

## 部门映射

`zentao/deptsync.go` 里的 `SyncDeptsFromDingTalk` 维护一张部门映射表：

- 钉钉部门 → 禅道部门 id；
- 支持改名、移动（父部门变化）；
- `ZENDAO_REQUIRE_DEPT_MATCH=true` 时，映射不到就不建人。

映射表结构见 `ensureDeptMapTable`，不匹配的日志关键字是 `zentao dept resolve failed`。

## 常见日志关键字

| 关键字 | 含义 |
|---|---|
| `Scheduled LDAP sync completed successfully.` | 定时全量成功 |
| `Scheduled LDAP sync failed:` | 定时全量失败，后面跟原因 |
| `Failed to (re)connect to LDAP` | 重连失败，通常是 LDAP 地址或管理员口令变了 |
| `zentao dept resolve failed` | 部门映射失败，人被建但没部门 |
| `Failed to start server` | 端口被占或权限问题 |

## 配置默认值（来自代码）

| 变量 | 默认 |
|---|---|
| `LDAP_URL` | `ldap://10.10.30.118:30778` |
| `LDAP_BASE_DN` | `dc=moyingrobotics,dc=com` |
| `SYNC_INTERVAL` | `1h` |
| `SERVER_PORT` | `:7777` |
| `ZENDAO_DB_PORT` | `3306` |
| `ZENDAO_DB_NAME` | `chandao` |
| `ZENDAO_DEFAULT_ROLE` | `dev` |
| `ZENDAO_REQUIRE_DEPT_MATCH` | `true` |

`ZENDAO_DEFAULT_PASSWORD` 有默认值，**必须改**，不能拿默认值上线。

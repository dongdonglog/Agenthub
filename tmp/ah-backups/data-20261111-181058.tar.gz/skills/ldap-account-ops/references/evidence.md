# 依据

路径相对 `platform/devops/tapd-work/moying-ldap`，行号取 2026-11-11 的 `main` 分支（最后提交 2026-08-19）。

## 已验证

| 结论 | 依据 | 类型 |
|---|---|---|
| 服务入口 `cmd.Cmd()`，监听 `SERVER_PORT`（默认 `:7777`） | `main.go`、`cmd/cmd.go:113`、`ldap/config/config.go` | 代码 |
| 启动时先全量同步，再按 `SYNC_INTERVAL` 定时 | `cmd/cmd.go:54-70` | 代码 |
| `SYNC_INTERVAL` 默认 1 小时 | `ldap/config/config.go:16` | 代码 |
| 路由：`/webhook`、`/tapd/webhook`、`/tapd/new/webhook`、`/dingtalk/webhook`、`/hour-alert/*` | `cmd/cmd.go:76-100` | 代码 |
| 定时同步失败只打日志，不退出进程 | `cmd/cmd.go:60-69` | 代码 |
| 本服务不写 `userPassword`（全仓库无该字段写入） | `grep -rn userPassword` 无结果 | 代码 |
| 禅道写入字段：`realname/email/mobile/dingding/dept/deleted` | `zentao/sync.go:129-156` | 代码 |
| 邮箱为空时不覆盖已有邮箱 | `zentao/sync.go:131-140` | 代码 |
| 离职是软删（`deleted=1`） | `zentao/sync.go:194`（`DeactivateUserByDingID`） | 代码 |
| 账号由邮箱/姓名/uid 推导，重名加后缀 | `zentao/sync.go:335`（`makeUniqueAccount`） | 代码 |
| 部门映射匹配不到就不写 dept | `zentao/sync.go:121-127` | 代码 |
| `ZENDAO_REQUIRE_DEPT_MATCH` 默认 true | `ldap/config/config.go`（`ZENDAO_REQUIRE_DEPT_MATCH` 默认值） | 代码 |
| 部署清单是 `moying-ldap.yaml`（`ldap-dingtalk`，镜像 `:latest`），NodePort 31777 → 7777 | `moying-ldap.yaml:4,18-19,85-88` | 代码 |
| OpenLDAP 对外走 `ldap-svc.yaml`，NodePort 30778 → 389 | `ldap-svc.yaml:15-21` | 代码 |
| `ldap.yaml` 是 OpenLDAP 服务端 + phpldapadmin，`ldap-svc.yaml` 只给 OpenLDAP 开 LoadBalancer | 两个文件内容对比 | 代码 |
| 代码里有多处硬编码兜底值（AppSecret、LDAP 管理员口令、禅道默认口令） | `dingtalk/config/config.go`、`ldap/config/config.go` | 代码 |

## 未验证

| 结论 | 状态 | 怎么确认 |
|---|---|---|
| 不写 `userPassword` 时下游靠什么鉴权 | 未知 | 问下游系统负责人，或看首次登录流程 |
| 全量同步会不会删掉手工添加的账号 | 逻辑上会覆盖，未实测 | 测试环境加一个假人跑一轮 |
| 禅道库的实际表前缀是不是 `zt_` | 代码里用 `zt_user` | `show tables like 'zt_user'` |

## 引用来源

- 仓库：`git@gitlab.moyingrobotics.com:platform/devops/tapd-work/moying-ldap.git`，分支 `main`
- 交接文档：`04-手册/06-moying-ldap.md`

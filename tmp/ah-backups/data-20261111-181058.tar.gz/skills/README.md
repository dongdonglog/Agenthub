# skills（冻结副本）

这里的四个 skill 是 **2026-11-11 的 1.0.0 版本快照**，跟着交接文档一起归档，方便离线看。

**源仓库在**：`git@gitlab.moyingrobotics.com:platform/ai-integration/devops-skills.git`

以后改 skill 去仓库里改，不要改这里——这里改了不会同步，也不会有 CI 校验。仓库里有：

- 校验器 `scripts/validate_skills.py`（frontmatter、命名、长度、链接、明文口令）
- GitLab CI：MR 和 tag 上跑 strict 校验 + 清单一致性检查
- 插件市场清单 `.claude-plugin/marketplace.json`
- 贡献指南 `CONTRIBUTING.md`、写作规范 `docs/writing-skills.md`
- 变更记录 `CHANGELOG.md`

## 从仓库安装（推荐）

```bash
git clone git@gitlab.moyingrobotics.com:platform/ai-integration/devops-skills.git
cp -r devops-skills/skills/* ~/.claude/skills/            # Claude Code
cp -r devops-skills/skills/* ~/.config/opencode/skills/   # opencode
cp -r devops-skills/skills/* ~/.cursor/skills/            # Cursor
```

或者用插件市场：

```text
/plugin marketplace add git@gitlab.moyingrobotics.com:platform/ai-integration/devops-skills.git
/plugin install devops-skills@moying-devops
```

## 用这份冻结副本

只有一种情况：接手的人拿不到 GitLab 权限，只能看交接包。那就直接 `cp -r skills/* ~/.claude/skills/`，四个目录都是完整可用的。

## 四个 skill

| skill | 什么时候用 |
|---|---|
| `tiangong-deploy` | 装天工机器、重跑某阶段、db-ha |
| `gitlab-cicd-release` | 发版、打 tag、promote、组件升级 |
| `tiangong-troubleshoot` | 贴报错、装不上、Pod 起不来 |
| `victorialogs-query` | 查日志、搜不到日志 |

细节和完整文档在 `../04-手册/` 和 `../07-故障处置.md`。

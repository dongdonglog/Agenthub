---
name: tiangong-deploy
description: 部署或重跑天工（tiangong）现场环境时使用。触发场景：用户说"装一台天工"、"现场部署"、"tiangong.sh 报错"、"只重装中间件/业务"、"部署卡在某一步"、"db-ha 双机"、"离线部署"。覆盖单机、集群、db-ha 三种模式，以及分阶段重跑。
license: Proprietary. See LICENSE in the repository root.
metadata:
  owner: donglai.ye
  version: 1.1.0
  updated: "2026-11-11"
  source: platform/devops/online-install
---

# 天工部署

## 先确认什么

不要直接给命令。先问清三件事：

1. **哪台机器、什么模式**：单机 / 集群 / db-ha。决定用哪个入口、哪个 inventory。
2. **装到哪一步了**：全新安装，还是某个阶段失败要重跑。
3. **是不是客户生产环境**：是的话先确认备份，任何"重装"建议都要加一句确认。

跑之前必须过的三项检查：

```bash
date -u                    # 时间偏差大 → 卡在下载，TLS 校验不过
ip -4 addr | head -5       # 记下网段，配 MetalLB 用，必须同段
df -h /                    # 至少留 50G
```

## 选入口

| 情况 | 命令 |
|---|---|
| 单台机器，全新 | `sudo ./tiangong.sh` |
| 多台，按 inventory 落点 | `sudo ./tiangong.sh --cluster` |
| 两台互为主备 | `sudo ./tiangong.sh --dbha` |
| 只装中间件 | `sudo ./tiangong.sh --middleware-only` |
| 只装业务 + 镜像 | `sudo ./tiangong.sh --apps-only` |
| 只重推镜像 + helm upgrade | `sudo ./tiangong.sh --post-mirror` |
| 只装 K3s 和网络 | `sudo ./tiangong.sh --k3s-only` |
| 只推配置仓库 | `sudo ./tiangong.sh --gitea-push` |

partial 参数之间**互斥**，组合错会直接 `exit 1` 并打印 `cannot be combined with`。完整参数矩阵和 inventory 分组见 [references/modes.md](references/modes.md)。

**客户问"我这规模该装哪种"**：看 [references/sizing.md](references/sizing.md)。一句话——脚本能自动装好的只有 Demo / 单机 / 主从备份，双机热备和五节点的自动切换要单独做，别按 `--dbha` 直接报工期。

## 主流程：先判断卡在哪

```text
时钟 → 内核检查 → 26.04 缓存 → Ansible → middleware-preflight
→ prepare:system → 14 个 playbook → K3s/helm → coredns → MetalLB
→ Endpoints → Gitea → Nexus EULA → 镜像替换 → 镜像同步
→ 业务 → 应用镜像同步 → 日志 → 自检
```

日志里会打印 `Running playbook: playbooks/xxx.yml`，**卡在哪一步就只重跑那一步**，不要从头发车。

每个阶段做什么、卡住长什么样、怎么单跑：见 [references/stages.md](references/stages.md)。

## 只重跑某一步

```bash
# 只重装中间件并自检，不动业务
sudo ./tiangong.sh --middleware-only

# 中间件已经好了，只重装业务 + 同步镜像
sudo ./tiangong.sh --apps-only

# 业务没变，只想重推镜像 + helm upgrade
sudo ./tiangong.sh --post-mirror

# 单跑一个 playbook（要自己准备 inventory 和 become 密码）
sudo ansible-playbook -i .generated/hosts.single playbooks/postgresql.yml
```

`.generated/hosts.single` 是上次运行生成的，里面有真实 IP，不会提交，换机器就要重新生成。

## 退出码

| 码 | 含义 | 动作 |
|---|---|---|
| 0 | 成功 | 跑验收清单 |
| 78 | 前置条件/升级未完成 | 看脚本最后的提示，通常是内核或 MongoDB |
| 79 | 需要重启或已提交重启 | 重启后用**原命令原参数**重跑 |
| 130 / 143 | 被 Ctrl-C / SIGTERM 打断 | 直接重跑 |
| 其他 | 真失败 | 定位阶段，别急着重装 |

78 和 79 **不是失败**。看到这两个码还建议用户"重装"就是错的。

## 装完必须验

```bash
kubectl -n middleware get pod
kubectl -n moying-business get pod,svc
kubectl -n moying-business get endpoints     # 空的就是没打通
kubectl get svc -A | grep LoadBalancer       # 有没有分到 IP
systemctl --no-pager status minio mongod emqx postgresql redis victoria-logs gitea rabbitmq-server nexus chrony | grep -E "Active:|failed"
```

`get endpoints` 为空是最常见的「装完了但业务连不上库」，重跑 `--apps-only`。完整验收清单见 [references/verification.md](references/verification.md)。

## 别做

- 不要在客户生产机上直接跑 `--dbha`：脚本自己标了「未实机验证」。
- 不要用 `dpkg -i --force-all` 或 `apt --allow-unauthenticated` 绕过校验：包装上了，数据会写坏。
- 不要在 `online-install/offline-tg-cluster/` 里改东西：那是本地未提交副本。
- 不要靠重装"修复"问题：playbook 幂等，先定位到阶段。
- 不要删 `.generated/` 当清理：里面的日志是排障依据。

## 深入

- [references/modes.md](references/modes.md)：参数矩阵、配置优先级、inventory 分组
- [references/stages.md](references/stages.md)：18 个阶段逐个说明
- [references/verification.md](references/verification.md)：装完验收与失败判据
- [references/sizing.md](references/sizing.md)：选型矩阵与「哪种方案脚本装不全」
- [references/evidence.md](references/evidence.md)：每条结论的出处与未验证项

# 参数、配置与 inventory

## 参数矩阵

| 参数 | 只做什么 | 会跳过什么 | 能否与别的组合 |
|---|---|---|---|
| `--cluster` | 多机模式 | 单机自动生成 inventory | 可与其他组合 |
| `--inventory <path>` | 指定 inventory | 默认 `./cluster-hosts` | 仅 cluster 模式有意义 |
| `--middleware-only` | 只装中间件并跑 verify | 业务、MetalLB 之后全部 | 不能与任何 partial 参数同用 |
| `--k3s-only` | 只装 K3s 和网络 | 中间件之后全部 | 不能与前一组的其他参数同用 |
| `--gitea-push` | 只推配置仓库 | 其他全部 | 不能与 apps / post-mirror / dashboard / k3s 同用 |
| `--apps-only` | 只装业务 + 镜像同步 | 中间件、logging | 不能与 post-mirror / dashboard / k3s 同用 |
| `--post-mirror` | 只做镜像 tag/push + helm upgrade | 业务首次安装 | 不能与 dashboard / k3s 同用 |
| `--dashboard-only` | 只看板 Helm release | 其他全部 | 不能与 k3s 同用 |
| `--k3s-tail-only` | 只跑 K3s 之后的收尾 | 前面全部 | 内部用 |
| `--cluster-tail-only` | 只在 master 跑收尾 | 前面全部 | 内部用 |
| `--dbha` | 转交 `tiangong-dbha.sh` | — | 独占 |

冲突参数会直接 `exit 1`，不是静默忽略。

## 配置优先级

同一个值可能出现在三处，从高到低：

1. 命令行 / 环境变量：`TIANGONG_SINGLE_CONFIG=/path/x.env`、`TIANGONG_SSH_USER=...`
2. 配置文件：单机读 `single-config.env`，集群读 `cluster-config.env`（`TIANGONG_CONFIG` 可改路径）
3. 自动探测 / 默认值：`detect_host_ip`、`detect_host_resources`、各 `apply_*_defaults`

排查「配置没生效」先查这里：环境变量会盖掉文件里的同名项。

单机模式没有 `single-config.env` 时会用默认值继续跑，不报错；但显式指定了 `TIANGONG_SINGLE_CONFIG` 而文件不存在，会直接退出。

## inventory 分组

单机和集群用同一套分组，区别只是模板里填不填。

| 分组 | 谁 | 空着会怎样 |
|---|---|---|
| `master` / `master-ext` | K3s 主节点 | 装不了 K3s |
| `works` | K3s 工作节点 | 单节点能跑，没有冗余 |
| `minio-ecs` | MinIO | 对象存储不可用 |
| `mongodb-replset` + `-master` / `-work` / `-Arb` | MongoDB 副本集 | 单机只填 `mongodb-single` |
| `postgresql` | PG | 业务数据库没有 |
| `redis` / `influxdb` / `victoria-logs` / `gitea` / `rabbitmq` / `nexus` | 各自中间件 | 对应功能缺失 |
| `emqx-master` / `emqx-ext` / `emqx-lb-master` / `emqx-lb-backup` | EMQX 与 LB | 单机跳过 LB |
| `ntp-server` / `ntp-client` | 时间源 | 退化成默认 NTP |

`[mongodb-replset:children]` 是聚合组，把 master/work/Arb 收进来。改 MongoDB 拓扑时三个子组都要改，只改一个会出现「副本集少成员」。

## 三个模式的差别

| 模式 | inventory 来源 | 特殊行为 |
|---|---|---|
| 单机 | `single-hosts` 模板 + 本机 IP 自动生成 | 跳过 `emqx-lb.yml`；日志打印 `Skipping EMQX LB playbook` |
| 集群 | `cluster-hosts`（或 `--inventory`） | 非 master 节点会 SSH 到 master 跑 tail 阶段 |
| db-ha | `dbha-hosts` + `dbha-config.env` | 转交 `tiangong-dbha.sh`，四阶段编排 |

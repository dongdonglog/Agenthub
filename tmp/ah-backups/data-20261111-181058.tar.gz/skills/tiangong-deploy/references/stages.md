# 阶段逐个说明

`tiangong.sh` 的执行顺序。日志里每进入一个 playbook 会打印 `Running playbook: playbooks/xxx.yml`，post-install 阶段会打印 `阶段 post-install:xxx`。

| # | 阶段 | 做什么 | 卡住时的样子 | 怎么单独跑 |
|---|---|---|---|---|
| 1 | `bootstrap-clock` | 检查并同步时间 | 后面 apt / TLS 报证书错误 | `sudo bash sh/bootstrap-clock.sh` |
| 2 | `bootstrap-kernel` | 检查内核，必要时引导升级（仅本地单机） | 退出 78 / 79 | 按提示装 `linux-generic` 后重启 |
| 3 | `prepare_ubuntu26_cache` | 26.04 走本地包，避免外网 | 找不到 bundle、校验失败 | `TIANGONG_UBUNTU26_BUNDLE=<dir> bash tiangong.sh` |
| 4 | `prepare_ansible` | 装/校验 ansible 可用 | Nexus 不通、pip 失败 | 手工装 ansible 后重跑 |
| 5 | `middleware-preflight` | 只读前置检查（内核、MongoDB 版本、未托管数据） | 直接红，**不重试** | 修好前置再整段重跑 |
| 6 | `prepare:system` | cloud-init 网络、清华 apt 源、LVM 扩容、装依赖、时区 | 包冲突、磁盘不足 | 单独跑 `prepare_target_system` 不方便，直接重跑主流程（幂等） |
| 7 | 14 个 playbook | 逐个装中间件 | 某个服务 failed | `ansible-playbook -i .generated/hosts.single playbooks/<name>.yml` |
| 8 | `config_helm` | 把 kubeconfig 放到用户目录 | 权限、`/etc/rancher/k3s/k3s.yaml` 不存在 | 重跑主流程 |
| 9 | `fix_coredns_loop_plugin` | 修 coredns 的 loop 插件 | 集群 DNS 解析异常 | 重跑主流程 |
| 10 | `wait_for_k3s_network_ready` | 等 K3s 网络就绪 | 一直等 | 看 `kubectl get node`、`kubectl -n kube-system get pod` |
| 11 | `post-install:metallb` | 装 MetalLB 与地址池 | `EXTERNAL-IP` 一直 pending | 检查地址池与机器是否同段，改完重跑 |
| 12 | `single_host_deployment` / `generate_svc_endpoints` | 生成 Service/Endpoints | Endpoints 为空 | 重跑 `--apps-only` 或主流程 |
| 13 | `post-install:endpoints` | 应用 Endpoints | 业务连不上宿主机中间件 | 同上 |
| 14 | `post-install:gitea` | 把配置仓库推到 Gitea | `repo not ready`、401 | 先确认 Gitea 和 PG 起来了 |
| 15 | `accept_nexus_eula` | 自动接受 Nexus EULA | 镜像拉取 401/403 | 单独跑 `--post-mirror` |
| 16 | `replace_images_from_env` | 按配置替换镜像地址 | 镜像地址还是旧的 | 检查 `single-config.env`、`values.generated.yaml`、`svc/` 三处 |
| 17 | `post-install:mirror` | 镜像 tag/push 到现场仓库 | 401、manifest unknown | 单独跑 `--post-mirror` |
| 18 | `post-install:business` | `helm upgrade --install moying-cloud` | Pod 起不来 | `kubectl -n moying-business describe pod` |
| 19 | `post-install:apps-mirror` | 业务镜像再同步一轮 | 同 17 | 单独跑 `--post-mirror` |
| 20 | `logging` | 部署日志采集与查询 | VictoriaLogs 未就绪（只 warn 不阻断） | 重跑主流程 |
| 21 | `post-install:status` | 等 `middleware` 命名空间全部 Running | 超时 | 看哪个 pod 不是 Running |

## 14 个 playbook 的顺序

顺序有依赖，不要调整：

```text
minio → mongodb → emqx → emqx-lb → postgresql → redis → influxdb
→ victoria-logs → gitea → rabbitmq → k3s → k3s_autofix → nexus → chrony
```

单机模式会跳过 `emqx-lb.yml`。

## 自愈与重试

- `tg_stage_run` 包住 post-install 阶段，`run_playbook_list` 包住每个 playbook；
- 致命退出码 **不重试**：5、78、79、99、130、143；
- `middleware-preflight.yml` 永远不重试，它必须保持只读；
- 重试前会做一次无破坏自愈：复位 systemd 单元、抓 journal、清临时状态。自愈只做幂等动作，失败也不影响后续重试。

## GUI 控制台相关

GUI 运行时会设置 `TIANGONG_EVENTS_FILE`，所有阶段事件写成 JSON 行进这个文件（`seq` / `ts` / `event` / `stage` / `task` / `status`）。

- 手工跑没有这个变量，事件静默丢弃；
- GUI 卡住时看这个文件的时间戳停在哪一个 stage；
- `ts` 是微秒精度，秒级会让「失败 → 重试」在排序里颠倒。

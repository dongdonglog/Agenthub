# 装完怎么验

`All steps completed` 不代表装好了。按这个顺序过一遍，任何一步不过就停下。

## 1. 中间件进程

```bash
systemctl --no-pager status minio mongod emqx postgresql redis influxdb \
  victoria-logs gitea rabbitmq-server nexus chrony | grep -E "Active:|failed"
```

期望：全部 `active (running)`，没有 `failed`。

## 2. K3s 与命名空间

```bash
kubectl get node
kubectl -n middleware get pod
kubectl -n moying-business get pod,svc
kubectl -n logging get pod
```

期望：

- node `Ready`；
- `middleware` 里没有 Pending / CrashLoopBackOff；
- `moying-business` 全 Running。

## 3. Endpoints（最容易漏）

```bash
kubectl -n moying-business get endpoints
```

期望：每个 Service 都有地址。**为空就是宿主机中间件没打通**，业务会报连接超时。

为空时的处理顺序：

1. 查 inventory 对应分组有没有填；
2. 查 `apply_svc_endpoints` 阶段有没有跑；
3. 重跑 `sudo ./tiangong.sh --apps-only`。

## 4. MetalLB

```bash
kubectl -n metallb-system get pod
kubectl get svc -A | grep LoadBalancer
```

期望：`EXTERNAL-IP` 是有值的地址，不是 `<pending>`。

pending 时对比地址池和机器网段：

```bash
kubectl -n metallb-system get ipaddresspool -o jsonpath='{.items[*].spec.addresses}'
ip -4 addr | grep inet
```

不在同一段就改 `metallb/templates/metallb-address-pool.yaml` 再重跑。

## 5. 镜像仓库

```bash
curl -k -u "$NEXUS_DOCKER_USER:$NEXUS_DOCKER_PASSWORD" \
  "https://<nexus-host>:31208/v2/_catalog"
```

期望：能看到业务镜像。401 通常是 EULA 没接受或账号不对。

## 6. 对外访问

```bash
curl -kI https://<业务对外IP>/
```

期望：`HTTP/1.1 200` 或 `302`。

## 失败对照表

| 现象 | 大概率原因 | 下一步 |
|---|---|---|
| Pod `ImagePullBackOff` | 现场仓库没这个 tag / 登录过期 | 跑 `--post-mirror`，再 `docker login` |
| Pod `CrashLoopBackOff` | 配置错 / 依赖没通 | `kubectl logs --previous` |
| Endpoints 为空 | inventory 分组没填 / 没跑 endpoints 阶段 | `--apps-only` |
| `EXTERNAL-IP` pending | 地址池不同段 | 改地址池 |
| 业务 502 | Endpoints 或中间件端口不通 | 先看 Endpoints，再 `nc -zv` |
| Nexus 401 | EULA / 账号 | 重跑 `--post-mirror` |

## 留档

装完把这三样存到现场交付记录里：

1. `kubectl get pod -A -o wide` 的输出；
2. `single-config.env`（**去掉口令**）；
3. 本次运行的 `.generated/` 日志目录。

下次出问题，这三样能省掉一半沟通。

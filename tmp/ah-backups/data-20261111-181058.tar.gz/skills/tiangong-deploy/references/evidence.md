# 依据

本 skill 的每条结论都能回到下面这些位置。仓库路径相对 `platform/devops/online-install`，行号取 2026-11-11 的 `develop` 分支。

## 已验证

| 结论 | 依据 | 类型 |
|---|---|---|
| 三个模式入口 `--cluster` / `--dbha` / 默认单机 | `tiangong.sh:246-262`（usage）、`tiangong.sh:3403-3420`（参数解析） | 代码 |
| partial 参数互斥，冲突直接 exit 1 | `tiangong.sh:3466-3480` | 代码 |
| 14 个 playbook 及顺序 | `tiangong.sh:8`（`PLAYBOOKS` 数组） | 代码 |
| 单机跳过 `emqx-lb.yml` | `tiangong.sh:1671-1674` | 代码 |
| 主流程阶段顺序 | `tiangong.sh` 的 `main()`，3403 行起至 3680 行 | 代码 |
| 退出码 78/79 的含义、不重试 | `tiangong.sh:88-94`（`tg_is_fatal_rc`）、`README.md:53` | 代码 + 文档 |
| 重试上限 3 次，可用 `TIANGONG_STAGE_MAX_ATTEMPTS` 改 | `tiangong.sh:84` | 代码 |
| preflight 永远不重试 | `tiangong.sh:1603-1680`（`run_playbook_list` 里的特判） | 代码 |
| 命名空间 `middleware` / `moying-business` / `logging` | `tiangong.sh:3055` / `2837` / `3087` | 代码 |
| Helm release 名 `moying-cloud` | `tiangong.sh:2837` | 代码 |
| MetalLB 地址池路径 | `metallb/templates/metallb-address-pool.yaml` | 文件 |
| inventory 分组名 | `single-hosts`、`cluster-hosts` | 文件 |
| 临时 inventory 在 `.generated/hosts.single` | `tiangong.sh:13` | 代码 |
| 单跑 playbook 的命令形态 | `tiangong.sh:1603`（`run_playbook_list` 构造的 ansible 命令） | 代码 |
| 配置优先级（环境变量 > 配置文件 > 默认） | `tiangong.sh:3555-3590`（`set -a` 加载配置文件前的 export） | 代码 |
| db-ha **无仲裁节点**，`mongo_deploy_arbiter` 默认关闭 | `tiangong-dbha.sh:168-169` | 代码 |
| 没有 Patroni / etcd 仲裁，PG 不会自动选主 | `grep -rn patroni` 无结果；`playbooks/postgresql-standby.yml` 只提供备库 | 代码 |
| keepalived 只用于 EMQX 接入层 VIP，不涉及数据库 | `playbooks/emqx-lb.yml:16-60` | 代码 |
| 容量矩阵（7 方案 × 3 档） | 售前《机器人产线服务器选型方案》2026-11-11 版 | 文档 |

## 未验证 / 需要在现场确认

| 结论 | 状态 | 怎么确认 |
|---|---|---|
| `--dbha` 的实际行为 | 脚本头注释自述「未实机验证（2026-09-03 交付）」，四阶段只按注释转述 | 测试环境跑一次 `sudo ./tiangong.sh --dbha`，看 `docs/db-ha-impl/交付报告.md` |
| `bootstrap-kernel.sh` 引导升级后一定能选到新内核 | 脚本不承诺 bootloader 选择 | 重启后 `uname -r` |
| 各现场端口（Nexus 31208、Gitea 31914、MetalLB 段） | 取自 `vars/*.yml` 默认值，现场可能被 `config.env` 覆盖 | 现场 `ss -lntp` |
| 中间件数据目录位置 | 散落在 playbook 里，未逐台确认 | `ls /var/lib/<组件>` |

## 引用来源

- 仓库：`git@gitlab.moyingrobotics.com:platform/devops/online-install.git`，分支 `develop`，最后提交 2026-11-04
- 交接文档：`04-手册/01-online-install.md`（同样内容的长版，含更多现场处置）
